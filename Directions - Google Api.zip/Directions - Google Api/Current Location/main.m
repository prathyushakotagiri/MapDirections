//
//  main.m
//  Current Location
//
//  Created by Prathyusha kotagiri on 9/24/15.
//  Copyright (c) 2015 Prathyusha kotagiri. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
