//
//  ViewController.m
//  Current Location
//
//  Created by Prathyusha kotagiri on 9/24/15.
//  Copyright (c) 2015 Prathyusha kotagiri. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.mapView.delegate = self;
    
    [self getCurrentLocation:nil];
}

#pragma mark - Alert
-(void)showAlert:(NSString *)message{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:message delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
    [alert show];
}

#pragma mark - Current Location
- (IBAction)getCurrentLocation:(id)sender{
   
    //Instantiate a location object.
    locationManager = [[CLLocationManager alloc] init];
    
    if ([[[UIDevice currentDevice] systemVersion] floatValue]>=8.0){
        [locationManager requestAlwaysAuthorization];
        //[locationManager requestWhenInUseAuthorization];
    }
    
    //Make this controller the delegate for the location manager.
    [locationManager setDelegate:self];
    
    if ([CLLocationManager locationServicesEnabled]==NO){
        [self showAlert:@"Location Services disabled. Please enable to proceed."];
        return;
    }else{
        //Start update the user's location
        [locationManager startUpdatingLocation];
    }
}

#pragma mark - CLLocation Manager Delegate methods
-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error{
    
    if (error.domain==kCLErrorDomain){
        [self showAlert:@"You denied/disabled Location Services for this app. Please enable Location Services at (Privacy Settings -> Location Services) to proceed."];
        
        return;
    }
}

-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations{
   
    CLLocation * newLocation = [locations objectAtIndex:0];
    
    if (newLocation == nil){
        [self showAlert:@"You denied/disabled Location Services for this app. Please enable Location Services at (Privacy Settings -> Location Services) to proceed."];
        return;
    }
    
    NSLog(@"%@",[NSString stringWithFormat:@"%f,%f", newLocation.coordinate.latitude, newLocation.coordinate.longitude]);
    
    sourceLocation = newLocation;
    
    //Reverse geocoding
    [self reverseGeocoding];

    //stop updating location manager
    [locationManager stopUpdatingLocation];
}

#pragma mark- Reverse Geocoding
-(void)reverseGeocoding
{
    CLGeocoder *geocoder=[[CLGeocoder alloc]init];
    
    [geocoder reverseGeocodeLocation:sourceLocation completionHandler:
     ^(NSArray *placemarks, NSError *error){
        
         if([placemarks count]>0){
             
             //Check whether user selects the current location,then display locality,city in textfields
             CLPlacemark *placemark = [placemarks objectAtIndex:0];
             
             NSLog(@"\n\nUnit:%@",placemark.subThoroughfare);//unit
             NSLog(@"Street:%@",placemark.thoroughfare);//street
             NSLog(@"Suburb:%@",placemark.subLocality);//suburb
             NSLog(@"City:%@",placemark.locality);//city
             NSLog(@"PostalCode:%@",placemark.postalCode);//postal code
             NSLog(@"%@",placemark.administrativeArea);//Country

             self.txtSource.text = [NSString stringWithFormat:@"%@,%@,%@", placemark.thoroughfare,placemark.locality,placemark.administrativeArea];
             
             [self addAnnotation:YES];
             
             //5KM circle
             _5kmCircle = [MKCircle circleWithCenterCoordinate:sourceAnnotation.coordinate radius:5000];
             _5kmCircle.title=@"outer";
             [self.mapView addOverlay:_5kmCircle];

         }else{
             [self showAlert:@"Could not find address"];
         }
         
     }];
}

#pragma mark - Source Annotation
-(void)addAnnotation:(BOOL)bValue{
    
    if (bValue) {
        
        if (!sourceAnnotation)
            sourceAnnotation = [[MKPointAnnotation alloc] init];
        
        sourceAnnotation.coordinate = sourceLocation.coordinate;
        sourceAnnotation.title = [self.txtSource.text capitalizedString];
        sourceAnnotation.subtitle = @"source";
        [self.mapView addAnnotation:sourceAnnotation];
        
    }else{
        
        if (!destAnnotation)
            destAnnotation = [[MKPointAnnotation alloc] init];
        
        destAnnotation.coordinate = destinationLocation.coordinate;
        destAnnotation.title = [self.txtDestination.text capitalizedString];
        destAnnotation.subtitle = @"destination";
        [self.mapView addAnnotation:destAnnotation];
    }
}


#pragma mark - Show Directions
- (IBAction)showDirections:(id)sender {
    
    //Resign firts responder
    [self.txtSource resignFirstResponder];
    [self.txtDestination resignFirstResponder];
    
    //Start animation
    [self.activityIndicator startAnimating];
    
    value =1;
    
    [self forwardGeocoding:1];//destination
    [self performSelector:@selector(forwardGeocoding:) withObject:@"2" afterDelay:1.0];//source
}


#pragma mark - Forward Geocoding
- (IBAction)forwardGeocoding:(int)iValue {
    
    NSString *strAddress;
    
    if (iValue == 1)
        strAddress = [[NSString stringWithFormat:@"%@",self.txtDestination.text] lowercaseString] ;
    else
        strAddress = [[NSString stringWithFormat:@"%@",self.txtSource.text] lowercaseString] ;
    
    //Google api to retreive the data
    NSString *url=[NSString stringWithFormat:@"https://maps.google.com/maps/api/geocode/json?address=%@&sensor=false&key=%@",strAddress,kGoogleApiKey];
    
    //Formulate the string as URL object.
    NSURL *googleRequestURL = [NSURL URLWithString:[url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    
    // Retrieve the results of the URL.
    dispatch_async(kBgQueue, ^{
        NSData *jsonData = [NSData dataWithContentsOfURL: googleRequestURL];
        [self performSelectorOnMainThread:@selector(fetchedgeocodeData:) withObject:jsonData waitUntilDone:YES];
    });
}

- (void)fetchedgeocodeData:(NSData *)responseData
{
    //If response is nil, display alert
    if (responseData == nil){
        [self showAlert:@"Check network"];
        return;
    }
    
    //Parse out the json data
    NSError *error;
    NSDictionary *json = [NSJSONSerialization
                          JSONObjectWithData:responseData
                          options:kNilOptions
                          error:&error];
    
    if (json == nil){
        [self showAlert:@"Check network"];
        return;
    }
    
    //The results from Google will be an array obtained from the NSDictionary object with the key "results".
    NSMutableArray *places =[[NSMutableArray alloc]init];
    places = [json objectForKey:@"results"];
    
    if ([places count]==0) {
        [self showAlert:@"Unable to find the address. Please try again."];
        return;
    }
    
    NSDictionary *geo=[[places objectAtIndex:0] objectForKey:@"geometry"];
    
    //Get the lat and long for the location.
    NSDictionary *loc = [geo objectForKey:@"location"];
    NSString *latitude = [loc objectForKey:@"lat"];
    NSString *longitude = [loc objectForKey:@"lng"];
    
    if (value == 1) {
        destinationLocation = [[CLLocation alloc] initWithLatitude:[latitude doubleValue] longitude:[longitude doubleValue]];
        value++;
    }else{
        sourceLocation = [[CLLocation alloc] initWithLatitude:[latitude doubleValue] longitude:[longitude doubleValue]];
    }
    
    [self performSelector:@selector(directionsGoogleApi) withObject:nil afterDelay:1.0];
}

#pragma mark - Route
-(void)directionsGoogleApi
{
    dispatch_async(kBgQueue, ^{
        
        [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
       
        NSString *strUrl = [NSString stringWithFormat:@"%@origin=%@&destination=%@&sensor=true&mode=driving",kBaseUrl,[NSString stringWithFormat:@"%f,%f",sourceLocation.coordinate.latitude,sourceLocation.coordinate.longitude],[NSString stringWithFormat:@"%f,%f",destinationLocation.coordinate.latitude,destinationLocation.coordinate.longitude]];
        //NSLog(@"%@",strUrl);
        
        strUrl=[strUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        NSData *data =[NSData dataWithContentsOfURL:[NSURL URLWithString:strUrl]];
        
        [self performSelectorOnMainThread:@selector(fetchedDirectionsData:) withObject:data waitUntilDone:YES];
    });
}

#pragma mark - json parser

- (void)fetchedDirectionsData:(NSData *)responseData {
   
    NSError* error;
    
    NSDictionary* json = [NSJSONSerialization
                          JSONObjectWithData:responseData //1
                          options:kNilOptions
                          error:&error];
    
    NSArray *arrRouts=[json objectForKey:@"routes"];
    
    if ([arrRouts isKindOfClass:[NSArray class]]&&arrRouts.count==0) {
        
        //Stop animating
        [self.activityIndicator stopAnimating];

        [self showAlert:@"Didn't find direction"];
        return;
    }
   

    //Get distance and duration parameters
    NSString *totalDuration = [[[json valueForKeyPath:@"routes.legs.duration.text"] objectAtIndex:0]objectAtIndex:0];
    NSString *totalDistance = [[[json valueForKeyPath:@"routes.legs.distance.text"] objectAtIndex:0]objectAtIndex:0];


    //Get source and destination coordinates
    double srcLat=[[[[json valueForKeyPath:@"routes.legs.start_location.lat"] objectAtIndex:0] objectAtIndex:0] doubleValue];
    double srcLong=[[[[json valueForKeyPath:@"routes.legs.start_location.lng"] objectAtIndex:0] objectAtIndex:0] doubleValue];
    double destLat=[[[[json valueForKeyPath:@"routes.legs.end_location.lat"] objectAtIndex:0] objectAtIndex:0] doubleValue];
    double destLong=[[[[json valueForKeyPath:@"routes.legs.end_location.lng"] objectAtIndex:0] objectAtIndex:0] doubleValue];
    
    
    
    /***** Add annotations on MapView ******/
    
    //Add source annotation
    sourceLocation = [[CLLocation alloc]initWithLatitude:srcLat longitude:srcLong];
    [self addAnnotation:YES];

    //Add destination annotation
    destinationLocation = [[CLLocation alloc]initWithLatitude:destLat longitude:destLong];
    [self addAnnotation:NO];
    
    
   
    
    //To set zoom level(From ios7)
    if ([[UIDevice currentDevice].systemVersion floatValue]>=7.0) {
        [self.mapView showAnnotations:self.mapView.annotations animated:YES];
    }else{
        
        CLLocationDistance meters = [sourceLocation distanceFromLocation:destinationLocation];
        
        MKCoordinateRegion region;
        region.center.latitude = (sourceLocation.coordinate.latitude + destinationLocation.coordinate.latitude) / 2.0;
        region.center.longitude = (sourceLocation.coordinate.longitude + destinationLocation.coordinate.longitude) / 2.0;
        region.span.latitudeDelta = meters / 111319.5;
        region.span.longitudeDelta = 0.0;
        
        
        MKCoordinateRegion _savedRegion = [_mapView regionThatFits:region];
        [_mapView setRegion:_savedRegion animated:YES];
    }
    
    
    //Remove overlays(routes,circle)
    [self removeOverlaysFromMapview];
    
    
    
    //Add 5KM circle around source coordinate in mapview
    _5kmCircle = [MKCircle circleWithCenterCoordinate:sourceAnnotation.coordinate radius:5000];
    _5kmCircle.title=@"outer";
    [self.mapView addOverlay:_5kmCircle];

    
    
    //Draw Route between source and destination
    NSArray* arrpolyline = [[[json valueForKeyPath:@"routes.legs.steps.polyline.points"] objectAtIndex:0] objectAtIndex:0]; //2
    
    NSMutableArray *polyLinesArray =[[NSMutableArray alloc]initWithCapacity:0];
    
    for (int i = 0; i < [arrpolyline count]; i++){
        NSString* encodedPoints = [arrpolyline objectAtIndex:i] ;
        MKPolyline *route = [self polylineWithEncodedString:encodedPoints];
        [polyLinesArray addObject:route];
    }
    
    [self.mapView addOverlays:polyLinesArray];
    
    //Stop animating
    [self.activityIndicator stopAnimating];
    
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    
    self.bckgndView.hidden = NO;
    
    self.lblDistance.text = [NSString stringWithFormat:@"Dist: %@",totalDistance];
    self.lblDuration.text = [NSString stringWithFormat:@"Dur: %@",totalDuration];
}

#pragma mark - decode map polyline
- (MKPolyline *)polylineWithEncodedString:(NSString *)encodedString {
    
    const char *bytes = [encodedString UTF8String];
    NSUInteger length = [encodedString lengthOfBytesUsingEncoding:NSUTF8StringEncoding];
    NSUInteger idx = 0;
    
    NSUInteger count = length / 4;
    CLLocationCoordinate2D *coords = calloc(count, sizeof(CLLocationCoordinate2D));
    NSUInteger coordIdx = 0;
    
    float latitude = 0;
    float longitude = 0;
    while (idx < length) {
        char byte = 0;
        int res = 0;
        char shift = 0;
        
        do {
            byte = bytes[idx++] - 63;
            res |= (byte & 0x1F) << shift;
            shift += 5;
        } while (byte >= 0x20);
        
        float deltaLat = ((res & 1) ? ~(res >> 1) : (res >> 1));
        latitude += deltaLat;
        
        shift = 0;
        res = 0;
        
        do {
            byte = bytes[idx++] - 0x3F;
            res |= (byte & 0x1F) << shift;
            shift += 5;
        } while (byte >= 0x20);
        
        float deltaLon = ((res & 1) ? ~(res >> 1) : (res >> 1));
        longitude += deltaLon;
        
        float finalLat = latitude * 1E-5;
        float finalLon = longitude * 1E-5;
        
        CLLocationCoordinate2D coord = CLLocationCoordinate2DMake(finalLat, finalLon);
        coords[coordIdx++] = coord;
        
        if (coordIdx == count) {
            NSUInteger newCount = count + 10;
            coords = realloc(coords, newCount * sizeof(CLLocationCoordinate2D));
            count = newCount;
        }
    }
    
    MKPolyline *polyline = [MKPolyline polylineWithCoordinates:coords count:coordIdx];
    free(coords);
    
    return polyline;
}


#pragma mark - Remove overlays
-(void)removeOverlaysFromMapview{
    
    NSArray *pointsArray=[self.mapView overlays];
    
    for (int i=0; i<[pointsArray count]; i++){
        [self.mapView removeOverlay:[pointsArray objectAtIndex:i]];
    }
}

#pragma mark - MKMapview delegate methods
- (MKOverlayRenderer *)mapView:(MKMapView *)mapView rendererForOverlay:(id < MKOverlay >)overlay{
    
    if ([overlay isKindOfClass:[MKCircle class]]) {
        
        MKCircle *circle=overlay;
        MKCircleRenderer *circleView = [[MKCircleRenderer alloc] initWithCircle:circle];
        circleView.lineWidth = 4;
        //circleView.fillColor = [UIColor redColor];
        if ([circle.title compare:@"outer"]==NSOrderedSame)
            circleView.strokeColor = [UIColor colorWithRed:89.0/255.0 green:156.0/255.0 blue:248.0/255.0 alpha:1];
        
        return circleView;

    }else if ([overlay isKindOfClass:[MKPolyline class]]){
       
        MKPolylineRenderer *renderer = [[MKPolylineRenderer alloc] initWithOverlay:overlay];
        renderer.strokeColor = [UIColor blueColor];
        renderer.lineWidth = 5.0;
        return renderer;
    }
    
    return  nil;
   
}

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id)annotation{
    
    // Try to dequeue an existing pin view first.
    MKPinAnnotationView *pinView = (MKPinAnnotationView*)[mapView dequeueReusableAnnotationViewWithIdentifier:@"CustomPinAnnotationView"];
    
    if (!pinView){
        // If an existing pin view was not available, create one.
        pinView = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"CustomPinAnnotationView"];
        
        //To hide/show default view of annotation
        [pinView setCanShowCallout:YES];
        
        [pinView setAnimatesDrop:YES];
    }else
        pinView.annotation = annotation;
    
    if ([[annotation subtitle] isEqualToString:@"source"]){
       // pinView.image=[UIImage imageNamed:@"locationGreen.png"];
        pinView.pinColor = MKPinAnnotationColorGreen;
    }else{
        //pinView.image=[UIImage imageNamed:@"locationRed.png"];
        pinView.pinColor = MKPinAnnotationColorRed;
    }
    
    return pinView;
}


#pragma mark - UITextField Delegate methods
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
   
    [self.txtSource resignFirstResponder];
    [self.txtDestination resignFirstResponder];

    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
